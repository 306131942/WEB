﻿' Copyright (c) Microsoft Corporation. All rights reserved.
' This class simply extends the TreeNode class by adding a Size field to support
' indicated directory size by color.
Public Class DirectoryNode
    Inherits TreeNode

    Public Size As Long

End Class

