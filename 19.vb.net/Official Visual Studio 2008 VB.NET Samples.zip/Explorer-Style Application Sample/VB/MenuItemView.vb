﻿' Copyright (c) Microsoft Corporation. All rights reserved.
' This class simply extends the MenuItem class to support a View property.
Class MenuItemView
    Inherits ToolStripMenuItem
    Public View As View
End Class
